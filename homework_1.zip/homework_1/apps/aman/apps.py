from django.apps import AppConfig


class AmanConfig(AppConfig):
    name = 'aman'
