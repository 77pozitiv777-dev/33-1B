from django.apps import AppConfig


class NuraiConfig(AppConfig):
    name = 'nurai'
